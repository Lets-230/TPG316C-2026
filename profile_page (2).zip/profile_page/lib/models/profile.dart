// In your Profile model, add Uint8List? imageBytes
// ignore_for_file: unnecessary_this

import 'dart:typed_data';

class Profile {
  String name;
  String surname;
  String cellphoneNumber;
  String email;
  String role;
  String programmingLanguage;
  Uint8List? imageBytes; // Use bytes instead of path for web

  Profile({
    required this.name,
    required this.surname,
    required this.cellphoneNumber,
    required this.email,
    required this.role,
    required this.programmingLanguage,
    this.imageBytes,
    String? imagePath,
  });

  String? get imagePath => null;

  Profile copyWith({required String imagePath}) {
    return Profile(
      name: this.name,
      surname: this.surname,
      cellphoneNumber: this.cellphoneNumber,
      email: this.email,
      role: this.role,
      programmingLanguage: this.programmingLanguage,
      imageBytes: this.imageBytes,
      imagePath: imagePath,
    );
  }

  // Update copyWith accordingly
}
