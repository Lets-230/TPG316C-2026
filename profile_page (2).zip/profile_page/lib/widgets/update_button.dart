import 'package:flutter/material.dart';

class UpdateButton extends StatelessWidget {
  final VoidCallback onUpdate;

  const UpdateButton({Key? key, required this.onUpdate}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onUpdate,
      child: const Text('Update Details'),
    );
  }
}
