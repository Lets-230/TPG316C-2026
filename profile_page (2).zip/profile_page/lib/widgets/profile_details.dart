import 'package:flutter/material.dart';

class ProfileDetails extends StatelessWidget {
  final String fullName;
  final String role;
  final String email;
  final String phoneNumber;
  final String programmingLanguage;

  const ProfileDetails({
    Key? key,
    required this.fullName,
    required this.role,
    required this.email,
    required this.phoneNumber,
    required this.programmingLanguage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(fullName,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(role, style: const TextStyle(fontSize: 16, color: Colors.grey)),
        const SizedBox(height: 20),
        Text('Email: $email', style: const TextStyle(fontSize: 16)),
        Text('Phone: $phoneNumber', style: const TextStyle(fontSize: 16)),
        Text('Programming Language: $programmingLanguage',
            style: const TextStyle(fontSize: 16)),
      ],
    );
  }
}
