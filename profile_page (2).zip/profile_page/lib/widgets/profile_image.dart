import 'package:flutter/material.dart';
import 'dart:io';
// ignore: unused_import
import 'package:image_picker/image_picker.dart';

class ProfileImage extends StatelessWidget {
  final String? imagePath; // Changed from File? to String?
  final VoidCallback onImagePick;

  const ProfileImage({
    Key? key,
    required this.imagePath,
    required this.onImagePick,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onImagePick,
      child: CircleAvatar(
        radius: 60,
        backgroundColor: Colors.grey[200],
        backgroundImage: _getImageProvider(),
        child: imagePath == null
            ? Icon(
                Icons.camera_alt,
                size: 40,
                color: Colors.grey[600],
              )
            : null,
      ),
    );
  }

  ImageProvider? _getImageProvider() {
    if (imagePath == null) return null;

    // For web, we need a different approach
    // Since we can't use FileImage on web, we'll use MemoryImage
    // But for now, return null and show icon
    // A better solution would be to use Image.network or base64

    try {
      // This works on mobile/desktop but not web
      return FileImage(File(imagePath!));
    } catch (e) {
      // Fallback for web
      return null;
    }
  }
}
