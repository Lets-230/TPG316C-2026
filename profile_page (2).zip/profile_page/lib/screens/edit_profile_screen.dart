// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../models/profile.dart';

class EditProfileScreen extends StatefulWidget {
  final Profile profile;

  const EditProfileScreen({Key? key, required this.profile}) : super(key: key);

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController _nameController;
  late TextEditingController _surnameController;
  late TextEditingController _phoneController;
  late TextEditingController _emailController;
  late TextEditingController _roleController;
  late TextEditingController _languageController;
  String? _imagePath;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.profile.name);
    _surnameController = TextEditingController(text: widget.profile.surname);
    _phoneController =
        TextEditingController(text: widget.profile.cellphoneNumber);
    _emailController = TextEditingController(text: widget.profile.email);
    _roleController = TextEditingController(text: widget.profile.role);
    _languageController =
        TextEditingController(text: widget.profile.programmingLanguage);
    _imagePath = widget.profile.imagePath;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _surnameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _roleController.dispose();
    _languageController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() => _imagePath = pickedFile.path);
    }
  }

  void _saveProfile() {
    // Basic validation
    if (_nameController.text.isEmpty ||
        _surnameController.text.isEmpty ||
        _phoneController.text.isEmpty ||
        _emailController.text.isEmpty ||
        _roleController.text.isEmpty ||
        _languageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please fill all fields'),
            backgroundColor: Colors.red),
      );
      return;
    }

    final updatedProfile = Profile(
      name: _nameController.text,
      surname: _surnameController.text,
      cellphoneNumber: _phoneController.text,
      email: _emailController.text,
      role: _roleController.text,
      programmingLanguage: _languageController.text,
      imagePath: _imagePath,
    );

    Navigator.pop(context, updatedProfile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        actions: [
          TextButton(
            onPressed: _saveProfile,
            child: const Text('Save',
                style: TextStyle(color: Colors.black, fontSize: 16)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Image picker
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: _imagePath != null
                        ? FileImage(File(_imagePath!))
                        : null,
                    child: _imagePath == null
                        ? const Icon(Icons.person, size: 60, color: Colors.grey)
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.blue,
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.camera_alt, color: Colors.white),
                        onPressed: _pickImage,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Form fields
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(labelText: 'Name')),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _surnameController,
                        decoration:
                            const InputDecoration(labelText: 'Surname')),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _phoneController,
                        decoration:
                            const InputDecoration(labelText: 'Cellphone')),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(labelText: 'Email')),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _roleController,
                        decoration: const InputDecoration(labelText: 'Role')),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _languageController,
                        decoration: const InputDecoration(
                            labelText: 'Programming Language')),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
