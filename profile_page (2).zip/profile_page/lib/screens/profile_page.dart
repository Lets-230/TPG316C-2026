// ignore_for_file: library_private_types_in_public_api, use_key_in_widget_constructors, unused_import

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/profile.dart';
import '../widgets/profile_image.dart';
import '../widgets/profile_details.dart';
import 'edit_profile_screen.dart';
import '../utils/image_picker_helper.dart'; // Add this

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late Profile _profile;

  @override
  void initState() {
    super.initState();
    _profile = Profile(
      name: 'Mpho',
      surname: 'Mbele',
      cellphoneNumber: '051 507 4382',
      email: 'mmbele@cut.ac.za',
      role: 'Software Developer',
      programmingLanguage: 'Dart',
      imagePath: null,
    );
  }

  Future<void> _pickImage() async {
    final pickedPath = await ImagePickerHelper.pickImage();
    if (pickedPath != null) {
      setState(() {
        _profile = _profile.copyWith(imagePath: pickedPath);
      });
    }
  }

  void _editProfile() async {
    final updatedProfile = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditProfileScreen(profile: _profile)),
    );
    if (updatedProfile != null) {
      setState(() => _profile = updatedProfile);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile Page'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editProfile,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ProfileImage(
              imagePath: _profile.imagePath,
              onImagePick: _pickImage,
            ),
            const SizedBox(height: 10),
            ProfileDetails(
              fullName: '${_profile.name} ${_profile.surname}',
              role: _profile.role,
              email: _profile.email,
              phoneNumber: _profile.cellphoneNumber,
              programmingLanguage: _profile.programmingLanguage,
            ),
          ],
        ),
      ),
    );
  }
}
