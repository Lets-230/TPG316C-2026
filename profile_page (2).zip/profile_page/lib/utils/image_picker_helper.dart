import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ImagePickerHelper {
  static Future<String?> pickImage() async {
    final ImagePicker picker = ImagePicker();
    
    try {
      final XFile? pickedFile = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 75,
      );
      
      if (pickedFile != null) {
        return pickedFile.path;
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
    
    return null;
  }
  
  // Helper method to get image provider based on platform
  static ImageProvider getImageProvider(String? imagePath) {
    if (imagePath == null) {
      return const AssetImage('assets/default_avatar.png'); // Add a default asset
    }
    
    // For web, we need to use NetworkImage or AssetImage
    // FileImage doesn't work on web
    if (imagePath.startsWith('http')) {
      return NetworkImage(imagePath);
    } else {
      // For mobile/desktop, use FileImage
      // For web, this will still fail, so we need a different approach
      try {
        return FileImage(File(imagePath));
      } catch (e) {
        return const AssetImage('assets/default_avatar.png');
      }
    }
  }
}