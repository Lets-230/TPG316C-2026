import 'package:flutter/material.dart';
import 'views/profile_page.dart';
 
void main() {
  runApp(MyApp());
}
 
class MyApp extends StatelessWidget {
const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
 
     return MaterialApp(
      title: 'Consultation App',
      debugShowCheckedModeBanner: false,
      home: ProfilePage(),
    );
  }
}