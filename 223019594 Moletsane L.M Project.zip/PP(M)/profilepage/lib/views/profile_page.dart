import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'edit_profile_page.dart';


 
class ProfilePage extends StatefulWidget {
 
  @override
  _ProfilePageState createState() => _ProfilePageState();
 
}
 
class _ProfilePageState extends State<ProfilePage> {
 
  String name = 'Hloks ';

  String surname='Lets';
 
  String role = 'Software Developer';
 
  String email = 'lesti@icloud.com';
 
  String phoneNumber = '074 482 5478';

  String programmingLanguage="Python";
 
  File? _image;
 
  final ImagePicker _picker = ImagePicker();
 
  Future<void> _pickImage() async {
 
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
 
    if (pickedFile != null) {
 
      setState(() {
 
        _image = File(pickedFile.path);
 
      });
 
    }
 
  }
 
  void _updateName(String newName) {
 
    setState(() {
 
      name = newName;
 
    });
 
  }
  void _updateRole(String newRole) {
 
    setState(() {
 
      role = newRole;
 
    });
 
  }
  void _updateEmail(String newEmail) {
 
    setState(() {
 
      email = newEmail;
 
    });
 
  }
 
  void _updatePhoneNumber(String newPhoneNumber) {
 
    setState(() {
 
      phoneNumber = newPhoneNumber;
 
    });
 
  }
  @override
 
  Widget build(BuildContext context) {
 
    return Scaffold(
 
      appBar: AppBar(
 
        title: Text('Profile Page'),
 
      ),
      body: Column(
 crossAxisAlignment: CrossAxisAlignment.start,
        children: [
 
          GestureDetector(
 
            onTap: _pickImage,
 
            child: CircleAvatar(
 
              radius: 50,
 
              backgroundImage: _image != null
 
                  ? FileImage(_image!)
 
                  : NetworkImage('https://picsum.photos/250?image=9') as ImageProvider,
 
              child: _image == null
 
                  ? Icon(
 
                      Icons.camera_alt,
 
                      size: 50,
 
                      color: Colors.white,
                    )
 
                  : null,
            ),
          ),
          SizedBox(height: 10),
          Text(
           'Name: $name',
 
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          Text(
           'Surname: $surname',
 
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
 
          Text(
            'Role : $role',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
 
          SizedBox(height: 20),
          Text(
            'Email: $email',
 
            style: TextStyle(fontSize: 16),
          ),
          Text(
 
            'Cell Phone Number: $phoneNumber',
 
            style: TextStyle(fontSize: 16),
          ),

          Text(
 
            'Programming Language: $programmingLanguage',
 
            style: TextStyle(fontSize: 16),
          ),
          
          

 
          SizedBox(height: 20),
 
          ElevatedButton(
 
           onPressed: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const EditProfilePage(name:'' ,surname:'' , cellPhoneNumber: '',email: '',role: '',language: '',),
      ),
    );
  },
            child: Text('Update Details'),
          ),
 
        ],
 
      ),
 
    );
 
  }
 
}