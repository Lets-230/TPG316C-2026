import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


class EditProfilePage extends StatefulWidget {
  final String name;
  final String surname;
  final String cellPhoneNumber;
  final String email;
  final String role;
  final String language;

  const EditProfilePage({
    Key? key,
    required this.name,
    required this.surname,
    required this.cellPhoneNumber,
    required this.email,
    required this.role,
    required this.language,
  }) : super(key: key);
 
  @override
 _EditProfilePageState createState() => _EditProfilePageState();
 
}




class _EditProfilePageState extends State<EditProfilePage>
{
  //Controllers for Text fields
  late TextEditingController nameController;
  late TextEditingController surnameController;
  late TextEditingController cellPhoneController;
  late TextEditingController emailController;
  late TextEditingController roleController;
  late TextEditingController languageController;

  //Default Image Path

  @override
  void initState()
  {
    super.initState();
    //Initialize Controllers with values passed from ProfilePage
    nameController=TextEditingController(text: widget.name);
    surnameController=TextEditingController(text: widget.surname);
    cellPhoneController=TextEditingController(text: widget.cellPhoneNumber);
    emailController=TextEditingController(text: widget.email);
    roleController=TextEditingController(text: widget.role);
    languageController=TextEditingController(text: widget.language);

  }

  //Save Profile and return updated data to profile Page
  void SaveProfile()
  {
    Navigator.pop(context,
    {

        'name':nameController.text,
        'surname':surnameController.text,
        'cellPhoneNumber':cellPhoneController.text,
        'email':emailController.text,
        'role':roleController.text,
        'language':languageController.text,
    }
    );

  }
  @override
  Widget build(BuildContext context)

  {
    return Scaffold(
      //App Bar
      appBar:AppBar(title:Text('Edit Profile',style: TextStyle(color:Colors.black),),backgroundColor:Colors.blue),

      //Scrollable body to avoid overflow
      body:SingleChildScrollView(
          padding:EdgeInsets.all(20),
          child:Column(
          children:[
              //Profile Image
              CircleAvatar(radius:60),

              //Text Fields for editing profile details
              TextField(
                controller:nameController,
                decoration:InputDecoration(labelText:'Name'),


              ),
              TextField(
                controller:surnameController,
                decoration:InputDecoration(labelText:'Surname'),


              ),
              TextField(
                controller:cellPhoneController,
                decoration:InputDecoration(labelText:'CellPhone'),


              ),
              TextField(
                controller:emailController,
                decoration:InputDecoration(labelText:'Email'),


              ),
              TextField(
                controller:roleController,
                decoration:InputDecoration(labelText:'Role'),


              ),
              TextField(
                controller:languageController,
                decoration:InputDecoration(labelText:'Programming Language'),


              ),

              SizedBox(height:20),


              //Save button to confirm changes
              ElevatedButton(
                  onPressed:SaveProfile,
                  child:Text('Save',style:TextStyle(color:Colors.black)),

              )




          ]
          )





      )















    
// @override
// void dispose() {
//   nameController.dispose();
//   surnameController.dispose();
//   cellPhoneController.dispose();
//   emailController.dispose();
//   roleController.dispose();
//   languageController.dispose();
//   super.dispose();
// }







    );
  }
}
